package hrms.hrms.entity;

public enum JobApplicationStatus {
    PENDING, 
    ACCEPTED, 
    REJECTED


}
